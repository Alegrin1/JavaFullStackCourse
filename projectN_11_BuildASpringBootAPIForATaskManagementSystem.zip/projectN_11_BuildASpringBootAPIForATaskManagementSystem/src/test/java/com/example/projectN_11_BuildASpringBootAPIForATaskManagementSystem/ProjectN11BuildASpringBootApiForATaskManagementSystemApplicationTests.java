package com.example.projectN_11_BuildASpringBootAPIForATaskManagementSystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjectN11BuildASpringBootApiForATaskManagementSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
