package com.example.projectN_11_BuildASpringBootAPIForATaskManagementSystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjectN11BuildASpringBootApiForATaskManagementSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjectN11BuildASpringBootApiForATaskManagementSystemApplication.class, args);
	}

}
